//ALL SHARED_DATA
//var SHARED_DATA = [];
module.exports = {
	'rol' : ['administrator', 'client']
	,'orderStatus' : ['unpaid', 'pending', 'delivered']
};
