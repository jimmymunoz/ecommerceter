module.exports = {
	'appName': 'FRAMEWORKS-JS-E-COMMERCE'
	,'secret': 'master1Inf0TERsecr3t'
    ,'database': 'mongodb://localhost:27017/sportster'
    ,'crypto_algorithm': 'aes-256-ctr'
    ,'crypto_password': 'TERsp27LjS'
    ,'time-user-session': 60 //une heure
    ,'default_pagesize_pagination': 9 //9 x page
};