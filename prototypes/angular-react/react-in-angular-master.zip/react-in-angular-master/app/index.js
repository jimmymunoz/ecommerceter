'use strict';

require('angular');
require('./index.scss');
require('./app');

